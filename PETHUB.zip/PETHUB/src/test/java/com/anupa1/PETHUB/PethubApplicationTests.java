package com.anupa1.PETHUB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PethubApplicationTests {

	@Test
	void contextLoads() {
	}

}
